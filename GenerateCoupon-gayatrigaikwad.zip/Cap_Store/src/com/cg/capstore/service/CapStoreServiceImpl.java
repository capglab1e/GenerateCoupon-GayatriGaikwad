package com.cg.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;



import com.cg.capstore.dao.ICapstoreDao;
import com.cg.capstore.dto.Coupon;

@Service("capstoreService")
@Transactional

public class CapStoreServiceImpl implements ICapstoreService 
{
	
	@Autowired
	ICapstoreDao capstoreDao;

	@Override
	public void insertdata(Coupon coupon) {
		// TODO Auto-generated method stub
		 capstoreDao.insertdata(coupon);
		
	}

	@Override
	public List<Coupon> getAllCoupons() {
		// TODO Auto-generated method stub
		return capstoreDao.getAllCoupons();
	}

}
