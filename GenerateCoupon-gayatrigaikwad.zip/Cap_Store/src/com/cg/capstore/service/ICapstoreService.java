package com.cg.capstore.service;

import java.util.List;

import com.cg.capstore.dto.Coupon;

public interface ICapstoreService 
{
	public void insertdata(Coupon coupon);
	public List<Coupon> getAllCoupons();
}
